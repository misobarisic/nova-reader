
	KeiyoushiKEI@9add655a78e96c4ec7a53ef89dccb557cb5d767489fac5e785d671a5a75d4da2"<
https://keiyoushi.github.iohttps://discord.gg/3FbCpdKbdY��
�
Manhwa18.cc,eu.kanade.tachiyomi.extension.all.manhwa18cc�
hhttps://github.com/keiyoushi/extensions/releases/download/0d83f6b-0/tachiyomi-all.manhwa18cc-v1.6.66.apkphttps://cdn.jsdelivr.net/gh/keiyoushi/extensions-source@main/src/all/manhwa18cc/res/mipmap-xhdpi/ic_launcher.png�hhttps://github.com/keiyoushi/extensions/releases/download/0d83f6b-0/tachiyomi-all.manhwa18cc-v1.6.66.jar"1.6(Ҽ21.6.668B0������CManhwa18.ccen"https://manhwa18.ccB0߇������_Manhwa18.ccko"https://manhwa18.ccB1�������Manhwa18.ccall"https://manhwa18.cc